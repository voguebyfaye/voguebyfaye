import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, CreditCard, Copy } from "lucide-react";

const products = [
  { id: 1, name: "Elegant Dress", price: 120, image: "/dress.jpg" },
  { id: 2, name: "Chic Handbag", price: 80, image: "/handbag.jpg" },
  { id: 3, name: "Stylish Heels", price: 95, image: "/heels.jpg" },
];

export default function VogueByFayeShop() {
  const [cart, setCart] = useState([]);
  const [checkout, setCheckout] = useState(false);
  const [copied, setCopied] = useState(false);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleCopy = () => {
    navigator.clipboard.writeText("7083813192");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-center">Vogue by Faye</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <Card key={product.id} className="rounded-2xl shadow-lg">
            <CardContent className="p-4">
              <img src={product.image} alt={product.name} className="rounded-xl mb-4 w-full h-48 object-cover" />
              <h2 className="text-xl font-semibold">{product.name}</h2>
              <p className="text-lg text-gray-600">${product.price}</p>
              <Button className="mt-2 w-full" onClick={() => addToCart(product)}>
                <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-10 border-t pt-6">
        <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
        {cart.length === 0 ? (
          <p className="text-gray-500">Your cart is empty.</p>
        ) : (
          <ul className="space-y-2">
            {cart.map((item, index) => (
              <li key={index} className="flex justify-between">
                <span>{item.name}</span>
                <span>${item.price}</span>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-4 flex justify-between font-semibold">
          <span>Total:</span>
          <span>${total}</span>
        </div>
        {cart.length > 0 && (
          <Button className="mt-4 w-full" onClick={() => setCheckout(true)}>
            <CreditCard className="mr-2 h-4 w-4" /> Proceed to Payment
          </Button>
        )}
      </div>

      {checkout && (
        <div className="mt-10 bg-gray-100 p-6 rounded-xl shadow-md">
          <h3 className="text-xl font-bold mb-4">Payment Options</h3>

          <div className="mb-6">
            <h4 className="font-semibold mb-2">💳 Option 1: Bank Transfer to Moniepoint</h4>
            <p><strong>Account Name:</strong> FARIDAH OKANDEJI</p>
            <p><strong>Account Number:</strong> 7083813192 <Button size="sm" onClick={handleCopy} className="ml-2"><Copy className="w-4 h-4 mr-1" /> {copied ? "Copied" : "Copy"}</Button></p>
            <p><strong>Bank:</strong> Moniepoint Microfinance Bank</p>
            <p className="mt-2 text-sm text-gray-600">After payment, send proof via email or WhatsApp.</p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">🛡 Option 2: PayPal (Coming Soon)</h4>
            <p className="text-sm text-gray-500">PayPal integration is currently being set up.</p>
          </div>
        </div>
      )}
    </div>
  );
}
